define({
	"button.formatlessPaste.tooltip": "Перемикач вставки без форматування"
});
