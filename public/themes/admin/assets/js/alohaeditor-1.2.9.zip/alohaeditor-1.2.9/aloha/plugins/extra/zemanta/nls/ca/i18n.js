define({
	"floatingmenu.tab.related": "Relacionat",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "Per cercar articles, imatges i etiquetes relacionades el servei del Zemanta necessita més de 140 caràcters."
});
