define({
	"button.formatlessPaste.tooltip": "Formatierung übernehmen/nicht übernehmen"
});
