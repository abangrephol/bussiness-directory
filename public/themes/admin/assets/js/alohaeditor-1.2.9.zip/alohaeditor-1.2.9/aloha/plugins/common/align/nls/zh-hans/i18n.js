define({
	"button.alignright.tooltip": "居右对齐",
	"button.alignleft.tooltip": "居左对齐",
	"button.aligncenter.tooltip": "居中对齐",
	"button.alignjustify.tooltip": "两端对齐"
});
