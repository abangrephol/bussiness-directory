define({
	"button.switch-metaview.tooltip": "在元视图和普通视图之间切换"
});
