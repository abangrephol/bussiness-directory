define({
	"button.formatlessPaste.tooltip": "Переключатель вставки без форматирования"
});
