define({
	"button.addlink.tooltip": "Вставить ссылку",
	"button.removelink.tooltip": "Убрать ссылку",
	"newlink.defaulttext": "Новая ссылка",
	"floatingmenu.tab.link": "Ссылка",
	"link.target.self": "Текущее окно",
	"link.target.blank": "Новое окно",
	"link.target.parent": "Родительский фрейм",
	"link.target.top": "Поверх всех фреймов",
	"link.target.framename": "Имя фрейма",
	"link.target.legend": "Цель",
	"link.title.legend": "Название",
	"insertLink": "ctrl+k"
});
