define({
	"button.addlink.tooltip": "Вставити посилання",
	"button.removelink.tooltip": "Прибрати посилання",
	"newlink.defaulttext": "Нове посилання",
	"floatingmenu.tab.link": "Посилання",
	"link.target.self": "Поточне вікно",
	"link.target.blank": "Нове вікно",
	"link.target.parent": "Батьківський фрейм",
	"link.target.top": "Поверх усіх фреймів",
	"link.target.framename": "Назва фрейма",
	"link.target.legend": "Ціль",
	"link.title.legend": "Назва",
	"insertLink": "ctrl+k"
});
