define({
	"button.switch-metaview.tooltip": "Перемикання між мета- та звичайним виглядом"
});
