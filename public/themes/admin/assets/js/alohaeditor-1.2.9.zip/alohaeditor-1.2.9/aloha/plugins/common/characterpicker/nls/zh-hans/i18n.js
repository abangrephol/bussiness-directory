define({
	"button.addcharacter.tooltip": "挑选特殊字符"
});
