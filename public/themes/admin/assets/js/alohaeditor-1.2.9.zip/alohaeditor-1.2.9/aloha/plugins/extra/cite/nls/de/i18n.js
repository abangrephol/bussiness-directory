define({
	"cite.button.add.quote": "Auswahl als Zitat formatieren",
	"cite.button.add.blockquote": "Auswahl als Zitat formatieren",
	"button.removeCite.tooltip": "Zitat entfernen"
});
