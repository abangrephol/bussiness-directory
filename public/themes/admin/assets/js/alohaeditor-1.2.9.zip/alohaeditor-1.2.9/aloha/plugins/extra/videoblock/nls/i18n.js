define({
	"root":  {
		"tab.video.label": "Video: ",
		"button.removevideo.tooltip": "Remove video"
	},
	"de": true
});
