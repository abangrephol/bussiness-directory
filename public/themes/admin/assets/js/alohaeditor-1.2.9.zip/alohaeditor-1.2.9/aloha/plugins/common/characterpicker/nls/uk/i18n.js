define({
	"button.addcharacter.tooltip": "вибрати спецсимвол"
});
