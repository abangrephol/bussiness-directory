define({
	"button.formatlessPaste.tooltip": "Уклучи/Исклучи лепење без стил"
});
