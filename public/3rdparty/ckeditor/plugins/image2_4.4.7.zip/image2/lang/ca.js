﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ca', {
	alt: 'Text alternatiu',
	btnUpload: 'Envia-la al servidor',
	captioned: 'Imatge amb subtítol',
	captionPlaceholder: 'Títol',
	infoTab: 'Informació de la imatge',
	lockRatio: 'Bloqueja les proporcions',
	menu: 'Propietats de la imatge',
	pathName: 'imatge',
	pathNameCaption: 'subtítol',
	resetSize: 'Restaura la mida',
	resizer: 'Clicar i arrossegar per redimensionar',
	title: 'Propietats de la imatge',
	uploadTab: 'Puja',
	urlMissing: 'Falta la URL de la imatge.'
} );
