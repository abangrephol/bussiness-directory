﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'pt', {
	alt: 'Texto Alternativo',
	btnUpload: 'Enviar para o Servidor',
	captioned: 'Imagem legendada',
	captionPlaceholder: 'Legenda',
	infoTab: 'Informação da Imagem',
	lockRatio: 'Proporcional',
	menu: 'Propriedades da Imagem',
	pathName: 'imagem',
	pathNameCaption: 'legenda',
	resetSize: 'Tamanho Original',
	resizer: 'Clique e arraste para redimensionar',
	title: 'Propriedades da Imagem',
	uploadTab: 'Enviar',
	urlMissing: 'O URL da fonte da imagem está em falta.'
} );
