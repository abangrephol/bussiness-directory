﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'tt', {
	border: 'Frame чикләрен күрсәтү',
	noUrl: 'Please type the iframe URL', // MISSING
	scrolling: 'Enable scrollbars', // MISSING
	title: 'IFrame үзлекләре',
	toolbar: 'IFrame'
} );
