﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'hu', {
	border: 'Legyen keret',
	noUrl: 'Kérem írja be a iframe URL-t',
	scrolling: 'Gördítősáv bekapcsolása',
	title: 'IFrame Tulajdonságok',
	toolbar: 'IFrame'
} );
