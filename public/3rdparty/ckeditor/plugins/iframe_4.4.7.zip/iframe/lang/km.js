﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'km', {
	border: 'បង្ហាញ​បន្ទាត់​ស៊ុម',
	noUrl: 'សូម​បញ្ចូល URL របស់ iframe',
	scrolling: 'ប្រើ​របារ​រំកិល',
	title: 'លក្ខណៈ​សម្បត្តិ IFrame',
	toolbar: 'IFrame'
} );
