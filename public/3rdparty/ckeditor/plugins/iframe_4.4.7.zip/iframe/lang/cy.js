﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'cy', {
	border: 'Dangos ymyl y ffrâm',
	noUrl: 'Rhowch URL yr iframe',
	scrolling: 'Galluogi bariau sgrolio',
	title: 'Priodweddau IFrame',
	toolbar: 'IFrame'
} );
