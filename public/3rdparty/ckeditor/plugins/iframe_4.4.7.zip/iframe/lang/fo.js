﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'fo', {
	border: 'Vís frame kant',
	noUrl: 'Vinarliga skriva URL til iframe',
	scrolling: 'Loyv scrollbars',
	title: 'Møguleikar fyri IFrame',
	toolbar: 'IFrame'
} );
