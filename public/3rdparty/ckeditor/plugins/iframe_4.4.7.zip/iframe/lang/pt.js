﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'pt', {
	border: 'Mostrar a borda da Frame',
	noUrl: 'Por favor, digite o URL da iframe',
	scrolling: 'Ativar barras de rolamento',
	title: 'Propriedades da IFrame',
	toolbar: 'IFrame'
} );
